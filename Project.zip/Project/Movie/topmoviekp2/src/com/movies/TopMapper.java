
	package com.movies;


	import java.io.IOException;
import java.text.ParseException;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

	import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

	public class TopMapper extends
	     Mapper<LongWritable, Text, NullWritable, Text> {
		TreeMap<Integer, Text>  treemap = new TreeMap<Integer, Text> ();
		 public void map(LongWritable key, Text value, Context context)
		            throws InterruptedException, IOException {
		            String line = ((Text) value).toString().trim();
		            String[] array=line.split("::");
		            
		            treemap.put(Integer.parseInt(array[1]), new Text(array[0]));
		            if(treemap.size()>20)
		            {
		            	treemap.remove(treemap.firstKey());
		            }
		 }
		  protected void cleanup(Context context) throws IOException, InterruptedException {

		            	for (Map.Entry<Integer, Text> entry : treemap.entrySet()) {
		            	context.write(NullWritable.get(), new Text (entry.getValue()+"::"+entry.getKey()));
		            	}
	}
	}
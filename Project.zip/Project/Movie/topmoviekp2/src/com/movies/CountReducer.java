package com.movies;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
public class CountReducer extends Reducer<Text, Text, Text, Text>{
	
	private ArrayList<Text> movielt= new ArrayList<Text>();
	private ArrayList<Text> ratinglt= new ArrayList<Text>();
	private Text outvalue = new Text();

    public void reduce(Text key, Iterable<Text>values,
         Context context) throws IOException, InterruptedException 
    	{
    		movielt.clear();
    		ratinglt.clear();
    		Text tot=new Text();
    		for(Text value:values)
    		{
    			if(value.charAt(0)=='M')
    			{
    				movielt.add(new Text(value.toString().substring(1)));
    			  
    			}
    			else if(value.charAt(0)=='R')
    			{
    				ratinglt.add(new Text(value.toString().substring(1)));
    			}
    				
    			
    		}
    		
    JoinLogic(context);
    }
    private void JoinLogic(Context context) throws IOException, InterruptedException {
    double sum = 0;
    if (!movielt.isEmpty() && !ratinglt.isEmpty()) {
    for (Text moviesData : movielt) {
    for (Text ratingData : ratinglt) {
    sum = sum + Double.parseDouble(ratingData.toString());
    }
    if (ratinglt.size() > 40) {
    double average = sum / ratinglt.size();
    outvalue.set(String.valueOf(average));
    context.write(moviesData, outvalue);
    }
    }
    }
    }
    }
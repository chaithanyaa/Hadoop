package com.movies;

import java.io.IOException;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
public class MovieReducer extends
     Reducer<Text, Text, Text, IntWritable>{
	private TreeMap<IntWritable,Text> map=new TreeMap<IntWritable,Text>();

    public void reduce(Text key, Iterable<Text>values,
         Context context) throws IOException, InterruptedException 
    	{
    		for(Text val: values)
    		{
    			map.put(new IntWritable(Integer.parseInt(val.toString())), key);
    		}
    		
    	if(map.size()>10)
    		{
    		map.remove(map.firstKey());
    		}
    	for(Entry<IntWritable,Text> entry :map.descendingMap().entrySet())
    	{
    		context.write(entry.getValue(), entry.getKey());
    	}
    }
}
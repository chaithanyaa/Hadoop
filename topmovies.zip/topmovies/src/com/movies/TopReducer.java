package com.movies;


import java.io.IOException;
import java.util.Map.Entry;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
public class TopReducer extends
     Reducer<NullWritable, Text, NullWritable,Text>
{
	TreeMap<Integer, Text>  treemap = new TreeMap<Integer, Text> ();
	public void reduce(Text key, Iterable<Text>values,
        Context context) throws IOException, InterruptedException 
   	{
   		for(Text val: values)
   		{
   			String array[]=val.toString().split("::");
   			treemap.put(Integer.parseInt(array[1]),new Text(array[0]));
   		}
   		if(treemap.size()>10)
   		{
   			treemap.remove(treemap.firstKey());
   		}
   		for (Map.Entry<Integer, Text> entry : treemap.entrySet()) {
        	context.write(NullWritable.get(), new Text (entry.getValue()+"::"+entry.getKey()));
        	}
   	}
}
package com.movies;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
public class CountReducer extends Reducer<Text, Text, Text, Text>{
	

    public void reduce(Text key, Iterable<Text>values,
         Context context) throws IOException, InterruptedException 
    	{
    		ArrayList<String> movielt= new ArrayList<String>();
    		ArrayList<String> ratinglt= new ArrayList<String>();
    		Text tot=new Text();
    		for(Text value:values)
    		{
    			if(value.charAt(0)=='M')
    			{
    				movielt.add(value.toString().substring(1));
    			  
    			}
    			else if(value.charAt(0)=='R')
    			{
    				ratinglt.add(value.toString().substring(1));
    			}
    				
    			
    		}
    		for (String moviesData : movielt) {
    		context.write(new Text(moviesData),new Text(String.valueOf(ratinglt.size())));}
}}
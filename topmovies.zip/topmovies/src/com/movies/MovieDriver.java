package com.movies;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
public class MovieDriver {
 
    
 
    public static void main(String[] args) throws Exception {        
     
     Configuration conf1=new Configuration();
     Job job = Job.getInstance(conf1);
     //JobConf job = new JobConf(MovieDriver.class);
     job.setJarByClass(MovieDriver.class);
     job.setJobName("top movies");
 
   //  job.setMapperClass(EmpMapper.class);
     job.setReducerClass(CountReducer.class);
     job.getConfiguration().set("mapreduce.output.textoutputformat.separator", "::");
     job.setOutputKeyClass(Text.class);
     job.setOutputValueClass(Text.class);
 
     MultipleInputs.addInputPath(job, new Path(args[0]),TextInputFormat.class, MovieMapper1.class);
     MultipleInputs.addInputPath(job, new Path(args[1]),TextInputFormat.class, MovieMapper2.class);
     FileOutputFormat.setOutputPath(job, new Path(args[2]));
 
    //int result= job.waitForCompletion(true) ? 0 : 1;
    if(job.waitForCompletion(true))
    {
    	Configuration conf2=new Configuration();
    	Job job1 = Job.getInstance(conf2);
        job1.setJarByClass(MovieDriver.class);
        job1.setJobName("top ten movies");
    
        job1.setMapperClass(TopMapper.class);
        job1.setReducerClass(TopReducer.class);
        
        job1.setNumReduceTasks(1);
    
        job1.setOutputKeyClass(NullWritable.class);
        job1.setOutputValueClass(Text.class);
    
        FileInputFormat.addInputPath(job1, new Path(args[2]));
        FileOutputFormat.setOutputPath(job1, new Path(args[3]));
    }
    else
    {
    	 FileOutputFormat.setOutputPath(job, new Path(args[4]));
    	 
    }
    }
 
}
	


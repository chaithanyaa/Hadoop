package com.movies;


import java.io.IOException;
import java.text.ParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MovieMapper2 extends
     Mapper<LongWritable, Text, Text, Text> {

	 public void map(LongWritable key, Text value, Context context)
	            throws InterruptedException, IOException {
	            String line = ((Text) value).toString().trim();
	            String outval= new String();
	            String[] array=line.split("::");
	            String movieid=array[1];
	            String ratings=array[2];
	            outval="R"+ratings;
	            context.write(new Text(movieid), new Text(outval));
    
    
}
}